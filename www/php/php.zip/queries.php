<?php

header( "Content-type: application/json" );

$servername = "mysql124832-testtafervendo.jelasticlw.com.br";
$username = "root";
$password = "RYRlep25150";
$db = "tafervendo";

function getAllPlaces($conn) {
    $sql = "SELECT * FROM places ORDER BY id";
    $statement=$conn->prepare($sql);
    $statement->execute();
    $results=$statement->fetchAll(PDO::FETCH_ASSOC);
    $json=json_encode($results);
    print_r($json);
}


try {
    $conn = new PDO("mysql:host=$servername;dbname=$db", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    getAllPlaces($conn);
}
catch(PDOException $e)
{
    echo "Connection failed: " . $e->getMessage();
}
?>