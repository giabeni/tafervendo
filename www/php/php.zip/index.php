<?php
include("queries.php");

?>